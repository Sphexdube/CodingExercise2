﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Project2
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] weighting = { 1, 3, 7, 1, 3, 7, 1 };
            int checkTotal = 0;
            string message = String.Empty;

            string input = String.Empty;
            Console.WriteLine(" Please [Enter] Reference Number");
            input = Console.ReadLine();

            if (validation(input))
            {
                int[] result = Array.ConvertAll(input.Substring(2, 7).ToString().ToArray(), x => (int)x - 48);

                for (int i = 0; i < 7; i++)
                {
                    checkTotal += (weighting[i] * result[i]);
                }
                int results = 10 - (checkTotal % 10);

                if (results.Equals(Convert.ToInt32(input.Substring(input.Length - 1, 1))))
                {
                    message = "Success";
                }
                else {
                    message = "Invalid Reference";
                }

                Console.WriteLine(message);
                Console.ReadLine();
            }
            else
            {
                Console.Write("Input was invalid! \n Press [Enter] to Exit \n");
                Console.ReadLine();
            }
        }
        public static bool validation(string input)
        {
            if (input.Length != 10)
            {
                return false;
            }

            if (!input.Substring(0, 2).ToUpper().Equals("CF"))
            {
                return false;
            }

            string weight = input.Substring(2, 7);
            if (!Regex.IsMatch(weight, @"\d"))
            {
                return false;
            }

            return true;
        }
    }
}
