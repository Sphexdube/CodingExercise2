﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Text.RegularExpressions;

namespace Project1
{

    public class Student
    {
        SqlConnection _connection;
        SqlCommand _command = new SqlCommand();
        SqlDataAdapter _dataAdapter;
        DataSet dataSet;

        string _pathFile;

        Validation valid = new Validation();
        TextFile file = new TextFile();

        public Student(string connString, string pathFile)
        {
            _connection = new SqlConnection(connString);
            _pathFile = pathFile;
        }
        public void retrieveReports(string input)
        {
            bool containsNum = Regex.IsMatch(input, @"\d");

            if (!containsNum && input != null)
            {
                List<string> split = new List<string>(input.Split(','));

                string chosenOption = valid.isVaildOption(split[0].Replace(" ", String.Empty).ToLower());

                if (chosenOption != null)
                {
                    switch (chosenOption)
                    {
                        case "ChildMarkReport":

                            if (split.Count > 1)
                            {
                                createReport("GetStudents", split[1]);
                            }
                            else
                            {
                                createReport("GetStudents");
                            }
                            break;

                        case "AverageClassReport":
                            createReport("GetStudentAverages");
                            break;

                        case "SportsTaken":
                            createReport("GetStudentActivities");
                            break;
                    }
                }
                else
                {
                    Console.Write("Input was invalid! \n Please [Enter] command or Press [Enter] to Exit \n");
                }
            }
            else
            {
                Console.Write("Input was invalid! \n Please [Enter] command or Press [Enter] to Exit \n");
            }

            input = Console.ReadLine();
            if (input != "")
            {
                retrieveReports(input);
                Console.ReadLine();
            }
           
        }
        public void createReport(string procedure, string value = null)
        {
            try
            {
                _command = new SqlCommand();
                _dataAdapter = new SqlDataAdapter();

                dataSet = new DataSet();

                _connection.Open();

                _command.Connection = _connection;
                _command.CommandType = CommandType.StoredProcedure;
                _command.CommandText = procedure;

                if (value != null)
                {
                    SqlParameter param = new SqlParameter("@name", value.Trim());
                    param.Direction = ParameterDirection.Input;
                    param.DbType = DbType.String;
                    _command.Parameters.Add(param);
                }

                _dataAdapter = new SqlDataAdapter(_command);
                _dataAdapter.Fill(dataSet);

                if (dataSet.Tables[0].Rows.Count > 0)
                {
                    file.WriteDataToFile(dataSet.Tables[0], _pathFile); //Path.GetDirectoryName(_pathFile)
                }
                else
                {
                    Console.WriteLine("\nNo Data Found!");
                }
                Console.Write("\nData Retrieved Successfully\n Please [Enter] command or Press [Enter] to Exit \n");

                _command.Dispose();
                _connection.Close();

                string input = Console.ReadLine();
                if (input != null)
                {
                    retrieveReports(input);
                }

                Console.ReadLine();
            }
            catch (Exception ex)
            {
                Console.Write(ex.Message);
                throw ex;
            }
        }
    }
}
