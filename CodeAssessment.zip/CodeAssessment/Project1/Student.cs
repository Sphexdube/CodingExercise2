﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Text.RegularExpressions;

namespace Project1
{

    public class Student
    {
        SqlConnection _connection;
        SqlCommand _command = new SqlCommand();
        SqlDataAdapter _dataAdapter;
        DataSet dataSet;

        public Student(string connString)
        {
            _connection = new SqlConnection(connString);
        }

        enum Procedures
        {
            GetStudents = 1,
            GetStudentAverages = 2,
            GetStudentActivities = 3
        }

        public DataTable retrieveData(int input)
        {
            try
            {
                _command = new SqlCommand();
                _dataAdapter = new SqlDataAdapter();

                dataSet = new DataSet();

                _connection.Open();

                string procedure = ((Procedures)input).ToString();

                _command.Connection = _connection;
                _command.CommandType = CommandType.StoredProcedure;
                _command.CommandText = procedure;

                _dataAdapter = new SqlDataAdapter(_command);
                _dataAdapter.Fill(dataSet);

                if (dataSet.Tables[0].Rows.Count > 0)
                {
                    return dataSet.Tables[0];
                }

                return null;
            }
            catch (Exception ex)
            {
                Console.Write(ex.Message);
                return null;
            }
            finally
            {
                _command?.Dispose();
                _connection?.Close();
            }
        }
    }
}
