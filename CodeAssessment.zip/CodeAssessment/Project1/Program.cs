﻿using System;

namespace Project1
{
    class Program
    {
        public static string connectionString = "Data Source=TRCPU8274;Initial Catalog=SchoolApp;Integrated Security=True;Connect Timeout=15;Encrypt=False;TrustServerCertificate=True;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";
        public static string pathFile = @"C:\Test\CodingTest\C#\Applicant\SchoolReports\Report.txt";

        static void Main(string[] args)
        {

            Student student = new Student(connectionString, pathFile);
            TextFormat format = new TextFormat();
            Validation vaild = new Validation();

            string input = String.Empty;
            Console.WriteLine(String.Format(" Please [Enter] command \n 1. {0} e.g {1}, Charles Green(optional)  \n 2. {2} \n 3. {3} \n", format.spaceCamelCase(vaild.options[0]), vaild.options[0], format.spaceCamelCase(vaild.options[1]), format.spaceCamelCase(vaild.options[2])));
            input = Console.ReadLine();
            
            student.retrieveReports(input);
            
        }
    }
}
