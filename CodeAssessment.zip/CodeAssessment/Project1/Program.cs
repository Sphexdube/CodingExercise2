﻿using System;
using System.Data;
using System.Linq;
using System.Text.RegularExpressions;

namespace Project1
{
    public class Program
    {
        static Student student = new Student("Data Source=TRCPU8274;Initial Catalog=SchoolApp;Integrated Security=True;Connect Timeout=15;Encrypt=False;TrustServerCertificate=True;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");
        static TextFile file = new TextFile(@"C:\\Test\CodingTest\\C#\Applicant\\SchoolReports\\Report.txt");

        static void Main(string[] args)
        {
            try
            {
                string input = String.Empty;
                bool quitFlag = false;

                DataTable dataTable = new DataTable();

                Console.WriteLine(" Press [Enter] to Exit\n");
                
                while (!quitFlag)
                {
                    Console.WriteLine(" Select:\n 1. Child Mark Report e.g {1}, Charles Green(optional)  \n 2. Average Class Report \n 3. Sports Taken \n");
                    input = Console.ReadLine();
                    if (input == "")
                    {
                        quitFlag = true;
                    }
                    else
                    {
                        bool containsNum = Regex.IsMatch(input, @"\d");
                        int value = Convert.ToInt32(input);

                        if (containsNum && input.Length == 1 && (value >= 1 && value <= 3))
                        {
                            dataTable = student.retrieveData(value);
                            if (dataTable.Rows.Count > 0)
                            {
                                Console.WriteLine(string.Format("\n {0} Records Retrieved", dataTable.Rows.Count));
                                string result = file.WriteDataToFile(dataTable);
                                Console.WriteLine(result + "\n");
                            }
                            else
                            {
                                Console.WriteLine("No Records Found! \n");
                            }
                        }
                        else
                        {
                            Console.WriteLine("\n Input is invalid! \n");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
