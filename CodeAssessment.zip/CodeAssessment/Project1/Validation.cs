﻿using System;

namespace Project1
{
    public class Validation
    {
        public string[] options = { "ChildMarkReport", "AverageClassReport", "SportsTaken" };
        public string isVaildOption(string chosenOption)
        {
            try
            {
                return Array.FindAll(options, s => s.ToLower().Equals(chosenOption))[0];
            }
            catch (Exception ex)
            {
                return null;
                throw ex;
            }
        }
    }
}
