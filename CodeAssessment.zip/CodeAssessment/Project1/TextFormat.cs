﻿using System.Text.RegularExpressions;

namespace Project1
{
    public class TextFormat
    {
        public string spaceCamelCase(string value)
        {
            return Regex.Replace(value, "([A-Z])", " $1").Trim();
        }
    }
}
