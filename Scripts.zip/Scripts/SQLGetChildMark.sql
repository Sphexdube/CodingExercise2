CREATE PROCEDURE [dbo].[GetChildMark]
(
	 @name varchar(50) = null,
	 @surname varchar(50) = null
)
AS
BEGIN
	DECLARE @StudentId int
	SET @StudentId = (SELECT st.StudentID 
	FROM Students st 
	WHERE st.StudentName = @name  and
	st.StudentSurname = @surname);

	WITH StudentsCTE 
	AS
	(
	SELECT sm.StudentID, sm.SubjectID, sm.Mark, st.StudentName, st.StudentSurname, sb.Subject
	FROM SubjectMarks sm
	INNER JOIN Students st
	ON sm.StudentID = st.StudentID
	INNER JOIN Subjects sb
	ON sm.SubjectID = sb.SubjectID
	WHERE sm.StudentID = @StudentId OR  @StudentId IS NULL
	)

	SELECT StudentName, StudentSurname, Subject, Mark FROM StudentsCTE 
	RETURN
END