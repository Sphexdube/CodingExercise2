CREATE PROCEDURE [dbo].[GetStudentActivities]
AS
BEGIN

	WITH StudentsCTE
	AS 
	(
	 SELECT st.StudentID, st.StudentName, st.StudentSurname, st.StudentAge, ISNULL(sp.Sport, 'Dancing') AS SportName
	 FROM Students st
	 LEFT JOIN StudentActivities sa
	 ON st.StudentID = sa.StudentID
	 LEFT JOIN Sports sp
	 ON sp.SportID = sa.SportID
	 )
	 SELECT StudentName, StudentSurname, StudentAge, SportName FROM StudentsCTE
	RETURN
END