CREATE PROCEDURE [dbo].[GetStudentAverages]
AS
BEGIN

	WITH StudentsCTE 
	AS
	(
	SELECT COUNT(*) as NumberOfSubjects, st.StudentName, st.StudentSurname,  CAST(AVG(sm.Mark) AS DECIMAL(12,2)) as AvgMark
		FROM SubjectMarks sm
		INNER JOIN Students st
		ON sm.StudentID = st.StudentID
		INNER JOIN Subjects sb
		ON sm.SubjectID = sb.SubjectID
		GROUP BY sm.StudentID, st.StudentName, st.StudentSurname
	)
	SELECT StudentName, StudentSurname, NumberOfSubjects, AvgMark  
	FROM StudentsCTE
	WHERE NumberOfSubjects > 4 
	RETURN
END

